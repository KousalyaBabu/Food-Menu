package com.example.jankomarket.data.category

data class SubResultSet (

	val cate_availability_id : String,
	val pro_subcate_id : String,
	val pro_subcate_category_id : String,
	val pro_subcate_name : String,
	val pro_subcate_short_description : String,
	val pro_subcate_description : String,
	val pro_subcate_image : String,
	val pro_subcate_slug : String
)