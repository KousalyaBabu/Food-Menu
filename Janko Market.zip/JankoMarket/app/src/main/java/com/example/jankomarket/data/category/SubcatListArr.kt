package com.example.jankomarket.data.category

data class SubcatListArr (
    val sub_common : SubCommon,
    val sub_result_set : List<SubResultSet>
)