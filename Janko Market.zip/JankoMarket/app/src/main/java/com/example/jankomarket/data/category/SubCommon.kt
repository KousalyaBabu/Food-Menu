package com.example.jankomarket.data.category

data class SubCommon (

	val image_source : String
)