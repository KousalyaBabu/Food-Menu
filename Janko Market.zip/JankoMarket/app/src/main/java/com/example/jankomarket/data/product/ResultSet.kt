package com.example.jankomarket.data.product

data class ResultSet (

	val subcategorie : List<Subcategories>
)