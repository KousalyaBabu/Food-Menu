package com.example.jankomarket.data.product

data class ProductTag (
	val pro_tag_name : String,
	val pro_tag_image : String,
	val tag_id : String,
	val tag_product_primary_id : Int,
	val tag_product_id : String
)