package com.example.jankomarket.data.product

data class Common (

	val product_image_source : String,
	val subcategory_image_url : String
)