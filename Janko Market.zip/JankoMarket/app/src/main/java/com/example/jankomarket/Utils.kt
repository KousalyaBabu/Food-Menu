package com.example.jankomarket

object Utils {
    const val API_ID="F60DC85C-6801-4536-8102-65D9A8666940"
    const val AVAIL_ID="634E6FA8-8DAF-4046-A494-FFC1FCF8BD11"
}