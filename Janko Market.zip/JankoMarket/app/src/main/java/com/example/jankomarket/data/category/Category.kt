package com.example.jankomarket.data.category

data class Category (

	val status : String,
	val result_set : List<ResultSet>,
	val common : Common
)