package com.example.jankomarket.data.category

data class Common (

	val category_image_url : String,
	val subcategory_image_url : String
)